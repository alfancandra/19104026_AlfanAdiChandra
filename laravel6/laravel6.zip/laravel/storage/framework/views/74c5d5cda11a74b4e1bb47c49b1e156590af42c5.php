<?php $__env->startSection('content'); ?>
    <h1>
        Alfan Adi Chandra 
    </h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Coding\web\19104026_AlfanAdiChandra\laravel5\resources\views/beranda.blade.php ENDPATH**/ ?>