@extends('base')

@section('content')
    <h1>
        Alfan Adi Chandra 
    </h1>
@endsection